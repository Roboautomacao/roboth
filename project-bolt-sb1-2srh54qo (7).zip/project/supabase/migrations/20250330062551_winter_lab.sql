/*
  # Estrutura completa do banco de dados

  1. Tabelas
    - `sub_accounts`: Armazena as subcontas do Google Ads
    - `campaigns`: Gerencia as campanhas publicitárias
    - `credit_cards`: Armazena informações de pagamento
    - `advertisements`: Controla os anúncios das campanhas

  2. Campos Principais
    - Todas as tabelas incluem:
      - `id` (uuid, chave primária)
      - `created_at` e `updated_at` (timestamps)
    - Relacionamentos definidos com chaves estrangeiras
    - Campos específicos para cada entidade

  3. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas de acesso baseadas no usuário autenticado
    - Proteção de dados sensíveis
*/

-- Criar tabela de subcontas
CREATE TABLE IF NOT EXISTS sub_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id text UNIQUE NOT NULL,
  name text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE',
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  descriptive_name text,
  currency_code text DEFAULT 'BRL',
  time_zone text DEFAULT 'America/Sao_Paulo',
  organization_name text,
  legal_name text,
  address text,
  city text,
  state text,
  postal_code text,
  is_advertising_agency boolean DEFAULT false,
  payment_mode text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de campanhas
CREATE TABLE IF NOT EXISTS campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  status text NOT NULL DEFAULT 'ACTIVE',
  budget decimal NOT NULL DEFAULT 0,
  start_date timestamptz NOT NULL,
  end_date timestamptz,
  type text NOT NULL,
  sub_account_id uuid NOT NULL REFERENCES sub_accounts(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de cartões de crédito
CREATE TABLE IF NOT EXISTS credit_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sub_account_id uuid NOT NULL REFERENCES sub_accounts(id) ON DELETE CASCADE,
  card_number_hash text NOT NULL,
  expiration_date text NOT NULL,
  card_holder_name text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Criar tabela de anúncios
CREATE TABLE IF NOT EXISTS advertisements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  name text NOT NULL,
  final_url text NOT NULL,
  video_id text,
  headline text,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE sub_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE advertisements ENABLE ROW LEVEL SECURITY;

-- Políticas para subcontas
CREATE POLICY "Usuários podem ver suas próprias subcontas"
  ON sub_accounts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem criar suas próprias subcontas"
  ON sub_accounts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Usuários podem atualizar suas próprias subcontas"
  ON sub_accounts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Usuários podem deletar suas próprias subcontas"
  ON sub_accounts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Políticas para campanhas
CREATE POLICY "Usuários podem ver campanhas de suas subcontas"
  ON campaigns FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = campaigns.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem criar campanhas em suas subcontas"
  ON campaigns FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = campaigns.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem atualizar campanhas de suas subcontas"
  ON campaigns FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = campaigns.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem deletar campanhas de suas subcontas"
  ON campaigns FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = campaigns.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

-- Políticas para cartões de crédito
CREATE POLICY "Usuários podem ver seus próprios cartões"
  ON credit_cards FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = credit_cards.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem criar cartões para suas subcontas"
  ON credit_cards FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = credit_cards.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem atualizar seus próprios cartões"
  ON credit_cards FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = credit_cards.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem deletar seus próprios cartões"
  ON credit_cards FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM sub_accounts
      WHERE sub_accounts.id = credit_cards.sub_account_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

-- Políticas para anúncios
CREATE POLICY "Usuários podem ver anúncios de suas campanhas"
  ON advertisements FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaigns
      JOIN sub_accounts ON sub_accounts.id = campaigns.sub_account_id
      WHERE campaigns.id = advertisements.campaign_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem criar anúncios em suas campanhas"
  ON advertisements FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM campaigns
      JOIN sub_accounts ON sub_accounts.id = campaigns.sub_account_id
      WHERE campaigns.id = advertisements.campaign_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem atualizar anúncios de suas campanhas"
  ON advertisements FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaigns
      JOIN sub_accounts ON sub_accounts.id = campaigns.sub_account_id
      WHERE campaigns.id = advertisements.campaign_id
      AND sub_accounts.user_id = auth.uid()
    )
  );

CREATE POLICY "Usuários podem deletar anúncios de suas campanhas"
  ON advertisements FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaigns
      JOIN sub_accounts ON sub_accounts.id = campaigns.sub_account_id
      WHERE campaigns.id = advertisements.campaign_id
      AND sub_accounts.user_id = auth.uid()
    )
  );