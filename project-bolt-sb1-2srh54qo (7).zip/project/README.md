# Google Ads Automation

Este projeto é uma aplicação para automação de Google Ads usando React, Vite, Supabase e a API do Google Ads.

## Requisitos

- Node.js 18.x
- npm 10.x

## Instalação

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/google-ads-automation.git
cd google-ads-automation
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
   - Copie o arquivo `.env.example` para `.env`
   - Preencha as variáveis com seus valores

4. Execute o projeto:
```bash
npm run dev
```

## Scripts Disponíveis

- `npm run dev`: Inicia o servidor de desenvolvimento
- `npm run build`: Compila o projeto para produção
- `npm start`: Inicia o servidor de produção
- `npm run lint`: Executa a verificação de código

## Deploy

### Heroku

1. Instale o [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
2. Faça login no Heroku: `heroku login`
3. Crie um novo app: `heroku create`
4. Configure as variáveis de ambiente no Heroku
5. Faça o deploy: `git push heroku main`

## Tecnologias

- React
- Vite
- TypeScript
- Supabase
- Google Ads API
- Tailwind CSS
- Tremor