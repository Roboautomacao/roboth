import { useEffect, useState } from 'react';
import { Card, Title, Text, Button, TextInput, Select, SelectItem } from '@tremor/react';
import { useRouter } from 'next/router';
import { createClient } from '@supabase/supabase-js';

export default function NovaSubconta() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: '',
    customer_id: '',
    descriptive_name: '',
    currency_code: 'BRL',
    time_zone: 'America/Sao_Paulo',
    organization_name: '',
    legal_name: '',
    address: '',
    city: '',
    state: '',
    postal_code: '',
    is_advertising_agency: false,
    payment_mode: 'CREDIT_CARD'
  });
  const [user, setUser] = useState(null);

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        router.push('/');
      } else {
        setUser(session.user);
      }
    });
  }, [router]);

  async function criarSubconta(e: React.FormEvent) {
    e.preventDefault();

    if (!user?.id) return;

    const { error } = await supabase.from('sub_accounts').insert([
      {
        ...formData,
        user_id: user.id,
      },
    ]);

    if (error) {
      console.error('Erro ao criar subconta:', error);
      return;
    }

    router.push('/dashboard/subcontas');
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="mx-auto max-w-2xl">
        <Card>
          <Title>Nova Subconta</Title>
          <Text className="mt-2">Preencha os dados da nova subconta</Text>

          <form onSubmit={criarSubconta} className="mt-6 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Text>Nome da Subconta</Text>
                <TextInput
                  name="name"
                  placeholder="Nome da subconta"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div>
                <Text>ID do Cliente</Text>
                <TextInput
                  name="customer_id"
                  placeholder="ID do cliente Google Ads"
                  value={formData.customer_id}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div>
                <Text>Nome Descritivo</Text>
                <TextInput
                  name="descriptive_name"
                  placeholder="Nome descritivo"
                  value={formData.descriptive_name}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>Nome da Organização</Text>
                <TextInput
                  name="organization_name"
                  placeholder="Nome da organização"
                  value={formData.organization_name}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>Razão Social</Text>
                <TextInput
                  name="legal_name"
                  placeholder="Razão social"
                  value={formData.legal_name}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>Endereço</Text>
                <TextInput
                  name="address"
                  placeholder="Endereço"
                  value={formData.address}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>Cidade</Text>
                <TextInput
                  name="city"
                  placeholder="Cidade"
                  value={formData.city}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>Estado</Text>
                <TextInput
                  name="state"
                  placeholder="Estado"
                  value={formData.state}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>CEP</Text>
                <TextInput
                  name="postal_code"
                  placeholder="CEP"
                  value={formData.postal_code}
                  onChange={handleInputChange}
                />
              </div>

              <div>
                <Text>Forma de Pagamento</Text>
                <Select
                  value={formData.payment_mode}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, payment_mode: value }))}
                >
                  <SelectItem value="CREDIT_CARD">Cartão de Crédito</SelectItem>
                  <SelectItem value="INVOICE">Fatura</SelectItem>
                </Select>
              </div>
            </div>

            <div className="flex items-center gap-2 mt-4">
              <input
                type="checkbox"
                id="is_advertising_agency"
                name="is_advertising_agency"
                checked={formData.is_advertising_agency}
                onChange={handleInputChange}
                className="rounded border-gray-300"
              />
              <label htmlFor="is_advertising_agency">É uma agência de publicidade</label>
            </div>

            <div className="flex justify-end space-x-2 mt-6">
              <Button
                type="button"
                color="gray"
                onClick={() => router.push('/dashboard/subcontas')}
              >
                Cancelar
              </Button>
              <Button type="submit" color="blue">
                Criar Subconta
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}