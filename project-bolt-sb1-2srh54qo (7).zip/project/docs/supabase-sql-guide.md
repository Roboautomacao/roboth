# Guia: Como Executar SQL no Supabase

## Interface Nova

### 1. Acessar o SQL Editor
1. Faça login no Supabase (https://app.supabase.com)
2. Selecione seu projeto
3. No menu lateral esquerdo, procure e clique em "SQL Editor"
4. Clique no botão azul "+ New Query"

## Interface Antiga

### 1. Acessar o Table Editor
1. Faça login no Supabase (https://app.supabase.com)
2. Selecione seu projeto
3. No menu lateral esquerdo, clique em "Table Editor"
4. Na parte superior da tela, você verá uma aba "SQL"
5. Clique na aba "SQL" para abrir o editor

### 2. Usar o Editor SQL
1. O editor SQL já estará aberto e pronto para uso
2. Cole seu código SQL diretamente no editor
3. Para executar:
   - Clique no botão "Run" verde, ou
   - Use o atalho do teclado Ctrl+Enter (Cmd+Enter no Mac)

### 3. Visualizar Resultados
1. Os resultados aparecerão na parte inferior do editor
2. Em caso de sucesso:
   - Os dados serão mostrados em formato de tabela
   - Uma mensagem de sucesso aparecerá em verde
3. Em caso de erro:
   - Uma mensagem de erro em vermelho será exibida

## Dicas Úteis (Ambas as Versões)
- Salve suas queries frequentes como favoritas
- Use ponto e vírgula (;) para separar múltiplos comandos SQL
- Mantenha um backup das suas queries importantes
- Teste queries complexas em pequenos conjuntos de dados primeiro